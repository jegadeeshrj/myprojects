How to run Project
==================
1. Download and Unzip file on your local system copy carrental .
2. Put carrental folder inside root directory

Database Configuration
======================
Open phpmyadmin
Create Database carrental
Import database carrental.sql (available inside zip package)

Registered User
===============
Open Your browser put inside browser “http://localhost/carrental”
Login Details for user: test@gmail.com/Test@12345

For Admin Panel
===============
Open Your browser put inside browser “http://localhost/carrental/admin”
Login Details for admin : admin/admin